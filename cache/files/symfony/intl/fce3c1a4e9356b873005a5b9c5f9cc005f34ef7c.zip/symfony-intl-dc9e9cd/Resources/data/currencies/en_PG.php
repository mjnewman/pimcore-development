<?php

return [
    'Names' => [
        'PGK' => [
            0 => 'K',
            1 => 'Papua New Guinean Kina',
        ],
    ],
];
