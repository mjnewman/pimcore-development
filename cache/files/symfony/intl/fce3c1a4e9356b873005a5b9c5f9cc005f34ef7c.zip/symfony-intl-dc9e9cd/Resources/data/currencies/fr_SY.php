<?php

return [
    'Names' => [
        'SYP' => [
            0 => 'LS',
            1 => 'livre syrienne',
        ],
    ],
];
