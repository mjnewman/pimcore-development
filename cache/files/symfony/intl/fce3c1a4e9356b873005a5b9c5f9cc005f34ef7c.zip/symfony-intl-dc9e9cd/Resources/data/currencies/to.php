<?php

return [
    'Names' => [
        'AUD' => [
            0 => 'AUD$',
            1 => 'Tola fakaʻaositelēlia',
        ],
        'EUR' => [
            0 => '€',
            1 => 'ʻEulo',
        ],
        'FJD' => [
            0 => 'FJD',
            1 => 'Tola fakafisi',
        ],
        'NZD' => [
            0 => 'NZD$',
            1 => 'Tola fakanuʻusila',
        ],
        'PGK' => [
            0 => 'PGK',
            1 => 'Kina fakapapuaniukini',
        ],
        'SBD' => [
            0 => 'SBD',
            1 => 'Tola fakaʻotusolomone',
        ],
        'TOP' => [
            0 => 'T$',
            1 => 'Paʻanga fakatonga',
        ],
        'VUV' => [
            0 => 'VUV',
            1 => 'Vatu fakavanuatu',
        ],
        'WST' => [
            0 => 'WST',
            1 => 'Tala fakahaʻamoa',
        ],
        'XPF' => [
            0 => 'CFPF',
            1 => 'Falaniki fakapasifika',
        ],
    ],
];
