<?php

return [
    'Names' => [
        'BOB' => [
            0 => 'Bs',
            1 => 'Boliviano',
        ],
        'PEN' => [
            0 => 'PEN',
            1 => 'Sol Peruano',
        ],
    ],
];
