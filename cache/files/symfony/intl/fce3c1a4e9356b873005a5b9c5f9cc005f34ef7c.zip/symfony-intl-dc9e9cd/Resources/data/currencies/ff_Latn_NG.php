<?php

return [
    'Names' => [
        'NGN' => [
            0 => '₦',
            1 => 'Nayraa Nijeriyaa',
        ],
    ],
];
