<?php

return [
    'Names' => [
        'PEN' => [
            0 => 'S/',
            1 => 'sol peruano',
        ],
    ],
];
