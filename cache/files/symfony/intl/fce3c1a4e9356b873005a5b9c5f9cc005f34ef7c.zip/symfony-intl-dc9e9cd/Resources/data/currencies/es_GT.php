<?php

return [
    'Names' => [
        'GTQ' => [
            0 => 'Q',
            1 => 'quetzal',
        ],
    ],
];
