<?php

return [
    'Names' => [
        'NAD' => [
            0 => '$',
            1 => 'Namibian Dollar',
        ],
    ],
];
