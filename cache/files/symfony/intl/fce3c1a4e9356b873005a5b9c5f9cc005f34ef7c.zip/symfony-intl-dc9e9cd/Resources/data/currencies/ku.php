<?php

return [
    'Names' => [
        'EUR' => [
            0 => '€',
            1 => 'ewro',
        ],
        'TRY' => [
            0 => '₺',
            1 => 'TRY',
        ],
    ],
];
