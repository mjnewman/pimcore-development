<?php

return [
    'Names' => [
        'GBP' => [
            0 => 'GB£',
            1 => 'British Pound',
        ],
        'SHP' => [
            0 => '£',
            1 => 'St Helena Pound',
        ],
    ],
];
