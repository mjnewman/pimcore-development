<?php

return [
    'Names' => [
        'mi' => 'Māori',
    ],
    'LocalizedNames' => [
    ],
];
