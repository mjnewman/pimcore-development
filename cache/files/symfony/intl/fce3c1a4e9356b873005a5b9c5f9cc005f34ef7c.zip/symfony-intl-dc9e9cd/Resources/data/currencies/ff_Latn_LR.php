<?php

return [
    'Names' => [
        'LRD' => [
            0 => '$',
            1 => 'Dolaar Liberiyaa',
        ],
    ],
];
