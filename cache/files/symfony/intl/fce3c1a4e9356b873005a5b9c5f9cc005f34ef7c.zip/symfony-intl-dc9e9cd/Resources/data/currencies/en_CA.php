<?php

return [
    'Names' => [
        'CAD' => [
            0 => '$',
            1 => 'Canadian Dollar',
        ],
        'VES' => [
            0 => 'VES',
            1 => 'Venezuelan Bolívar',
        ],
    ],
];
