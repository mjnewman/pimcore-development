CHANGELOG
=========

5.3
---

 * The component is not marked as `@experimental` anymore

5.2.0
-----

 * Introduced the component as experimental
