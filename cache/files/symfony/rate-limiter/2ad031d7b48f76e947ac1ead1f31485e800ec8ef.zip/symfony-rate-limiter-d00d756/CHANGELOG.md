CHANGELOG
=========

5.2.0
-----

 * added the component
