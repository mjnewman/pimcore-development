sabre/xml
=========

[![Build Status](https://secure.travis-ci.org/sabre-io/xml.svg?branch=master)](http://travis-ci.org/sabre-io/xml)

The sabre/xml library is a specialized XML reader and writer.

Documentation
-------------

* [Introduction](http://sabre.io/xml/).
* [Installation](http://sabre.io/xml/install/).
* [Reading XML](http://sabre.io/xml/reading/).
* [Writing XML](http://sabre.io/xml/writing/).


Support
-------

Head over to the [SabreDAV mailing list](http://groups.google.com/group/sabredav-discuss) for any questions.

Made at fruux
-------------

This library is being developed by [fruux](https://fruux.com/). Drop us a line for commercial services or enterprise support.
