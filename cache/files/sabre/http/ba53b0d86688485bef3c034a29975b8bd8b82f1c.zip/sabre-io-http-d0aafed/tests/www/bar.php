<?php

header('X-Test: Bar');
?>
bar
